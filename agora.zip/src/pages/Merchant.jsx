/** @format */

import React from "react";
import Navbar from "../components/layout/Navbar";

const Merchant = () => {
  return (
    <div>
      <Navbar />
      <section className='text-center'>
        <h2>Increase your e-commerce store sales </h2>
        <h2>Increase your e-commerce store sales </h2>
        <h2>Increase your e-commerce store sales </h2>
        <h2>Increase your e-commerce store sales </h2>
      </section>
    </div>
  );
};
export default Merchant;
