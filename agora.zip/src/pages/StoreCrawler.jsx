/** @format */

import React from "react";

function StoreCrawler() {
  return <div>StoreCrawler</div>;
}

export default StoreCrawler;
