/** @format */

import React from "react";

function Docs() {
  return <div>Docs</div>;
}

export default Docs;
