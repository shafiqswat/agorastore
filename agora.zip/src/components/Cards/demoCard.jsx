/** @format */

import React from "react";

const DemoCard = () => {
  return <div>demoCard</div>;
};

export default DemoCard;
