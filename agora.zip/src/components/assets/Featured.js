/** @format */

const items = [
  {
    image1: "/images/featuredCard1.webp",
    image2: "/images/featuredCard2.webp",
    image3: "/images/featuredCard3.webp",
    image4: "/images/featuredCard4.webp",
    paraText: "City backpacks",
  },
  {
    image1: "/images/featuredCard1.webp",
    image2: "/images/featuredCard2.webp",
    image3: "/images/featuredCard3.webp",
    image4: "/images/featuredCard4.webp",
    paraText: "City backpacks",
  },
  {
    image1: "/images/featuredCard1.webp",
    image2: "/images/featuredCard2.webp",
    image3: "/images/featuredCard3.webp",
    image4: "/images/featuredCard4.webp",
    paraText: "City backpacks",
  },
  {
    image1: "/images/featuredCard1.webp",
    image2: "/images/featuredCard2.webp",
    image3: "/images/featuredCard3.webp",
    image4: "/images/featuredCard4.webp",
    paraText: "City backpacks",
  },
  {
    image1: "/images/featuredCard1.webp",
    image2: "/images/featuredCard2.webp",
    image3: "/images/featuredCard3.webp",
    image4: "/images/featuredCard4.webp",
    paraText: "City backpacks",
  },
  {
    image1: "/images/featuredCard1.webp",
    image2: "/images/featuredCard2.webp",
    image3: "/images/featuredCard3.webp",
    image4: "/images/featuredCard4.webp",
    paraText: "City backpacks",
  },
  {
    image1: "/images/featuredCard1.webp",
    image2: "/images/featuredCard2.webp",
    image3: "/images/featuredCard3.webp",
    image4: "/images/featuredCard4.webp",
    paraText: "City backpacks",
  },
  {
    image1: "/images/featuredCard1.webp",
    image2: "/images/featuredCard2.webp",
    image3: "/images/featuredCard3.webp",
    image4: "/images/featuredCard4.webp",
    paraText: "City backpacks",
  },
];
export default items;
