/** @format */

const items = [
  {
    image: "/images/compare1.webp",
    paraText: "Buckled Maxi Croco Black Leather Tote Bag with...",
    price: "$698.00",
    brand: "Mac Duggal",
    agoraScore: 3.2,
    customerRating: 0,
  },
  {
    image: "/images/compare2.webp",
    paraText: "Ebony Croc Minimal Backpack",
    price: "$99.00",
    brand: "Diaper Bag",
    agoraScore: 2.8,
    customerRating: 0,
  },
  {
    image: "/images/compare3.webp",
    paraText: "Annette Top Handle, Black Lizard, Black Onyx",
    price: "$2450.00",
    brand: "Darby Scott",
    agoraScore: 3.2,
    customerRating: 0,
  },
  {
    image: "/images/compare4.webp",
    paraText: "Dragon Diffusion x Todd Snyder Woven Leather Shopper Tote I...",
    price: "$650.00",
    brand: "Dragon Diffusion",
    agoraScore: 2.25,
    customerRating: 0,
  },
];
export default items;
