/** @format */

import React, { createContext, useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";

// Create Auth Context
const AuthContext = createContext();

const AuthProvider = ({ children }) => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const navigate = useNavigate();

  // Login User
  const login = async (email, password) => {
    setLoading(true);
    setError(null);
    try {
      const { data } = await axios.post(
        "https://agora.histudio.co/api/v1/auth/login",
        { email, password }
      );

      localStorage.setItem("token", data.data.token);
      setIsAuthenticated(true);
      setUser(data.data.user);
      navigate("/");
    } catch (error) {
      setError("Login failed. Please check your credentials.");
      console.error("Login failed:", error);
    } finally {
      setLoading(false);
    }
  };

  // Signup
  const signup = async (firstName, lastName, email, password) => {
    setLoading(true);
    setError(null); // Reset error state
    try {
      const { data } = await axios.post(
        "https://agora.histudio.co/api/v1/auth/signup",
        {
          firstname: firstName,
          lastname: lastName,
          email: email,
          password: password,
        }
      );

      localStorage.setItem("token", data.data.token);
      setIsAuthenticated(true);
      setUser(data.data.user);
      navigate("/");
    } catch (error) {
      setError("Signup failed. Please try again.");
      console.error("Signup failed:", error);
    } finally {
      setLoading(false);
    }
  };

  // Google Login
  const loginWithGoogle = () => {
    window.location.href = "https://agora.histudio.co/api/v1/auth/google";
  };

  // Handle Google OAuth Redirect
  useEffect(() => {
    const handleGoogleRedirect = async () => {
      const params = new URLSearchParams(window.location.search);
      const token = params.get("token");

      if (token) {
        // Store the token in localStorage
        localStorage.setItem("token", token);
        setIsAuthenticated(true);

        try {
          // Fetch authenticated user details
          const { data } = await axios.get(
            "https://agora.histudio.co/api/v1/auth/me",
            {
              headers: { Authorization: `Bearer ${token}` },
            }
          );

          setUser(data.data.user);
          navigate("/"); // Redirect after successful login
        } catch (error) {
          setError("Failed to authenticate with Google.");
          console.error("Google authentication failed:", error);
        }
      }
    };

    handleGoogleRedirect();
  }, [navigate]);

  // Logout User
  const logout = () => {
    localStorage.removeItem("token");
    setIsAuthenticated(false);
    setUser(null);
    navigate("/login");
  };

  // Fetch User Data if Token Exists
  useEffect(() => {
    const token = localStorage.getItem("token");
    setLoading(true);

    if (token) {
      axios
        .get("https://agora.histudio.co/api/v1/auth/me", {
          headers: { Authorization: `Bearer ${token}` },
        })
        .then((response) => {
          setUser(response.data.data.user);
          setIsAuthenticated(true);
        })
        .catch((error) => {
          if (error.response && error.response.status === 401) {
            localStorage.removeItem("token");
            setIsAuthenticated(false);
            setUser(null);
          }
          setError("Failed to fetch user data.");
          console.error("Error fetching user:", error);
        })
        .finally(() => {
          setLoading(false);
        });
    } else {
      setLoading(false);
    }
  }, []);

  return (
    <AuthContext.Provider
      value={{
        isAuthenticated,
        user,
        loading,
        setError,
        error,
        login,
        signup,
        logout,
        loginWithGoogle, // Expose the Google login method
      }}>
      {children}
    </AuthContext.Provider>
  );
};

export { AuthContext, AuthProvider };
