/** @format */

import React from "react";

function Terms() {
  return <div>Terms</div>;
}

export default Terms;
